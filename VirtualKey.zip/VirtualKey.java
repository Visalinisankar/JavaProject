package VirtualKey;

import java.io.File;
import java.util.Arrays;
import java.util.Scanner;

public class VirtualKey {
	public static void main(String[] args)  {
		File folder = new File("C://phase1");
	    folder.mkdirs();
	    Scanner sc = new Scanner(System.in);
	    while(true){
	    	System.out.println("Prototype of the Application - LockedMe.com");
	        System.out.println("Developer : Visalini.S\n");
	        System.out.println("The Functions are \n");
	        System.out.println("1. Retrive current filename in ascending order\n");
	        System.out.println("2. Business level operation menu  \n");
	        System.out.println("3. Exit from the application\n");
	        System.out.println("Choose the option you want to go with \n");
	        int choice = sc.nextInt();
	        switch(choice){
	                case 1:
	                    File arr[] = folder.listFiles();
	                    Arrays.sort(arr);
	                    for(int i=0;i<arr.length;i++)
	                        System.out.println(arr[i]);
	                        break;
	                case 2:
	                    Boolean temp = true;
	                    while(temp) {
	                        System.out.println("Option 1 : To Add a file in the existing Directory\n");
	                        System.out.println("Option 2 : To Delete a file from the existing Directory\n");
	                        System.out.println("Option 3 : To Search a user specified file from the Directory\n");
	                        System.out.println("Option 4 : Back to the previous menu\n");
	                        System.out.println("Option 5 : Terminate Program\n");
	                        int choice2 = sc.nextInt();
	                        switch (choice2) {
	                            case 1:
	                                File f = new File("C://phase1");
	                                System.out.println("Enter a file name");
	                                String name = sc.next();
	                                if(new File(folder,name).exists()){
	                                    System.out.println("File already exist\n");
	                                }else {
	                                    File folder1 = new File(folder, name);
	                                    folder1.mkdir();
	                                    if (new File(folder, name).exists()) {
	                                        System.out.println("File added successfully\n");
	                                    }
	                                }
	                                break;
	                            case 2:
	                                System.out.println("Enter a file name");
	                                String name1 = sc.next();
	                                boolean folder2 = new File(folder, name1).exists();
	                                System.out.println(folder2);
	                                if (folder2 == true) {
	                                    File folder3 = new File(folder, name1);
	                                    folder3.delete();
	                                    System.out.println("File successfully deleted\n");
	                                } else {
	                                    System.out.println("File does not exist\n");
	                                }
	                                break;
	                            case 3:
	                                System.out.println("Enter a keyword to search");
	                                String search = sc.next();
	                                File arr1[] = folder.listFiles();
	                                for(int a=0;a<arr1.length;a++){
	                                    if(arr1[a].getName().equalsIgnoreCase(search)){
	                                        System.out.println(arr1[a]);
	                                        System.out.println("File Found\n");
	                                        break;
	                                    }else{
	                                        System.out.println("File Not Found\n");
	                                    }
	                                }
	                                break;
	                            case 4:
	                                temp = false;
	                                break;
	                            case 5:
	                                System.out.println("Program Terminated Successfully\n");
	                                System.exit(0);
	                            default:
	                                System.out.println("Incorrect Input :( \nRetry\n");
	                        }
	                    }
	                    break;
	                case 3:
	                    System.out.println("Program Terminated Successfully");
	                    System.exit(0);
	                default:
	                    System.out.println("Incorrect Input :( \nRetry\n");
	                    break;
	            }
	        }
	    }
	}